# GRIP @The Spark Foundation : Data Science & Business Analytics Intern

# Name : Om Prakash

# Task 01 : Prediction using Supervised ML



PROBLEM:

Predict the percentage of student on the basis of study hours.

What will be predict score if we a student studies for 9.5 houres/day?

DATASET - 'http://bit.ly/w-data'
# Improt Libraries


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
```

# import the dataset


```python
url = "http://bit.ly/w-data"
df = pd.read_csv(url)
print('dataset import successfully!')
```

    dataset import successfully!
    


```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>25.000000</td>
      <td>25.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>5.012000</td>
      <td>51.480000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2.525094</td>
      <td>25.286887</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.100000</td>
      <td>17.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2.700000</td>
      <td>30.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>4.800000</td>
      <td>47.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>7.400000</td>
      <td>75.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>9.200000</td>
      <td>95.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2.5</td>
      <td>21</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5.1</td>
      <td>47</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.2</td>
      <td>27</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8.5</td>
      <td>75</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3.5</td>
      <td>30</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.isnull()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>5</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>6</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>7</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>8</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>9</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>10</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>11</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>12</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>13</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>14</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>15</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>16</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>17</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>19</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>20</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>21</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>22</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>24</th>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
</div>



# Visualising Data


```python
df.plot(x='Hours',y='Scores',style='o',c='g')
plt.xlabel('Hours studies')
plt.xlabel('Score in percentage')
plt.title('Hours vs Score')
plt.show()
```


    
![png](output_12_0.png)
    

This graphs shows a linear relation between Hours and Score
# Splitting the data


```python
x = df.iloc[:,:-1].values
y = df.iloc[:,1].values
```


```python
x_train, x_test, y_train, y_test= train_test_split(x, y, test_size= 0.2, random_state=0 )
regressor = LinearRegression()
regressor.fit(x_train.reshape(-1,1), y_train)

print('training complete.')
```

    training complete.
    

# Train the model


```python
line = regressor.coef_*x+regressor.intercept_
```


```python
plt.scatter(x, y)
plt.plot(x, line, color="red")
plt.show()
```


    
![png](output_19_0.png)
    


# Making Predications


```python
print(x_test)
y_pred = regressor.predict(x_test)
```

    [[1.5]
     [3.2]
     [7.4]
     [2.5]
     [5.9]]
    


```python
df = pd.DataFrame({'Actual': y_test, 'Predicted': y_pred})
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Actual</th>
      <th>Predicted</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>20</td>
      <td>16.884145</td>
    </tr>
    <tr>
      <th>1</th>
      <td>27</td>
      <td>33.732261</td>
    </tr>
    <tr>
      <th>2</th>
      <td>69</td>
      <td>75.357018</td>
    </tr>
    <tr>
      <th>3</th>
      <td>30</td>
      <td>26.794801</td>
    </tr>
    <tr>
      <th>4</th>
      <td>62</td>
      <td>60.491033</td>
    </tr>
  </tbody>
</table>
</div>



# Estimating Training and test score


```python
print('Training Score:', regressor.score(x_train, y_train))
```

    Training Score: 0.9515510725211552
    


```python
print('Test Score:', regressor.score(x_test, y_test))
```

    Test Score: 0.9454906892105356
    

# Plotting the bar graph to depict the diffrence between the actual and predicated value


```python
df.plot(kind='bar')
plt.grid(which='major', linewidth='0.5', color='orange')
plt.grid(which='minor', linewidth='0.5', color='red')
plt.show()
```


    
![png](output_27_0.png)
    


# Evaluating mean absolute error


```python
from sklearn import metrics
print('Mean Absolute Eroor:', metrics.mean_absolute_error(y_test, y_pred))
```

    Mean Absolute Eroor: 4.183859899002975
    

# Testing the model with our own data


```python
hours = 9.5
test = np.array([hours])
test = test.reshape(-1,1)
own_pred = regressor.predict(test)
print('No of Hours={}'.format(hours))
print('Predicted Score:{}'.format(own_pred[0]))
```

    No of Hours=9.5
    Predicted Score:96.16939660753593
    
Therefore, the predicted score of student who studies for 9.5 hours/day is  96.16939660753593 
# Thanks for Watching 
